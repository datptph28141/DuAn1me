/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModels;

/**
 *
 * @author Admin
 */
public class QLNhanVien {

    private String maQLNV, tenQLNV, gTinhQLNV, ngaySinhQLNV, diaChiQLNV, sdtQLNV, cmndQLNV, emailQLNV, ghiChuQLNV;

    public QLNhanVien() {
    }

    public QLNhanVien(String maQLNV, String tenQLNV, String gTinhQLNV, String ngaySinhQLNV, String diaChiQLNV, String sdtQLNV, String cmndQLNV, String emailQLNV, String ghiChuQLNV) {
        this.maQLNV = maQLNV;
        this.tenQLNV = tenQLNV;
        this.gTinhQLNV = gTinhQLNV;
        this.ngaySinhQLNV = ngaySinhQLNV;
        this.diaChiQLNV = diaChiQLNV;
        this.sdtQLNV = sdtQLNV;
        this.cmndQLNV = cmndQLNV;
        this.emailQLNV = emailQLNV;
        this.ghiChuQLNV = ghiChuQLNV;
    }

    public String getMaQLNV() {
        return maQLNV;
    }

    public void setMaQLNV(String maQLNV) {
        this.maQLNV = maQLNV;
    }

    public String getTenQLNV() {
        return tenQLNV;
    }

    public void setTenQLNV(String tenQLNV) {
        this.tenQLNV = tenQLNV;
    }

    public String getgTinhQLNV() {
        return gTinhQLNV;
    }

    public void setgTinhQLNV(String gTinhQLNV) {
        this.gTinhQLNV = gTinhQLNV;
    }

    public String getNgaySinhQLNV() {
        return ngaySinhQLNV;
    }

    public void setNgaySinhQLNV(String ngaySinhQLNV) {
        this.ngaySinhQLNV = ngaySinhQLNV;
    }

    public String getDiaChiQLNV() {
        return diaChiQLNV;
    }

    public void setDiaChiQLNV(String diaChiQLNV) {
        this.diaChiQLNV = diaChiQLNV;
    }

    public String getSdtQLNV() {
        return sdtQLNV;
    }

    public void setSdtQLNV(String sdtQLNV) {
        this.sdtQLNV = sdtQLNV;
    }

    public String getCmndQLNV() {
        return cmndQLNV;
    }

    public void setCmndQLNV(String cmndQLNV) {
        this.cmndQLNV = cmndQLNV;
    }

    public String getEmailQLNV() {
        return emailQLNV;
    }

    public void setEmailQLNV(String emailQLNV) {
        this.emailQLNV = emailQLNV;
    }

    public String getGhiChuQLNV() {
        return ghiChuQLNV;
    }

    public void setGhiChuQLNV(String ghiChuQLNV) {
        this.ghiChuQLNV = ghiChuQLNV;
    }

}
